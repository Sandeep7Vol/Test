package com.ncr.chess;

import java.util.logging.Logger;

public class ChessBoard {

	public static int MAX_BOARD_WIDTH = 7;
	public static int MAX_BOARD_HEIGHT = 7;

	private Pawn[][] pieces;
	private static Logger log = Logger.getLogger("ChessBoard");

	public ChessBoard() {
		pieces = new Pawn[MAX_BOARD_WIDTH][MAX_BOARD_HEIGHT];
	}

	public void addPiece(Pawn pawn, int xCoordinate, int yCoordinate, PieceColor pieceColor) {
		
		/**
		 * First check if the coordinate are inside the board and position is available.
		 */
		if (isLegalBoardPosition(xCoordinate, yCoordinate) && pieces[xCoordinate][yCoordinate] == null) {
			log.info("It is a legal postion and position is also empty so we are safe to keep it");
			pawn.setChessBoard(this);
			pawn.setXCoordinate(xCoordinate);
			pawn.setYCoordinate(yCoordinate);
			pawn.setPieceColor(pieceColor);
			pieces[xCoordinate][yCoordinate] = pawn;
		} else {
			log.info("As the position is already filled we cannot place the other pawn in the same position so setting the x and y coordinates as -1");
			pawn.setChessBoard(this);
			pawn.setXCoordinate(-1);
			pawn.setYCoordinate(-1);
			pawn.setPieceColor(pieceColor);
		}
	}

	public boolean isLegalBoardPosition(int xCoordinate, int yCoordinate) {
		/**
		 * in this case we are just checking if the xCoordinate and yCoordinate is inside MAX_BOARD_WIDTH and MAX_BOARD_HEIGHT
		 * 
		 * in future this can also be extended like as black pawn can only be on 6th row and white on 1st row. it cannot be on 0 or 7th row respectively
		 */

		return xCoordinate >= 0 && xCoordinate < MAX_BOARD_WIDTH && yCoordinate >= 0 && yCoordinate < MAX_BOARD_HEIGHT;

	}
}
