package com.ncr.chess;

import java.util.logging.Logger;

public class Pawn {

	private ChessBoard chessBoard;
	private int xCoordinate;
	private int yCoordinate;
	private PieceColor pieceColor;
	private static Logger log = Logger.getLogger("ChessBoard");

	public Pawn(PieceColor pieceColor) {
		this.pieceColor = pieceColor;
	}

	public ChessBoard getChessBoard() {
		return chessBoard;
	}

	public void setChessBoard(ChessBoard chessBoard) {
		this.chessBoard = chessBoard;
	}

	public int getXCoordinate() {
		return xCoordinate;
	}

	public void setXCoordinate(int value) {
		this.xCoordinate = value;
	}

	public int getYCoordinate() {
		return yCoordinate;
	}

	public void setYCoordinate(int value) {
		this.yCoordinate = value;
	}

	public PieceColor getPieceColor() {
		return this.pieceColor;
	}

	public void setPieceColor(PieceColor value) {
		pieceColor = value;
	}

	public void move(MovementType movementType, int newX, int newY) {
		/**
		 * Check if the move is valid or not. For example a black pawn at position (6,3) can only move to position
		 * (5,3)/(5,4)/(5,2). So put a condition respectively or else it is not a valid move.
		 */
		if (newX >= 0 && newX < ChessBoard.MAX_BOARD_WIDTH && newX >= 0 && newX < chessBoard.MAX_BOARD_HEIGHT) {
			if ((getXCoordinate() - 1 == newX && getYCoordinate() == newY)
					|| (getXCoordinate() - 1 == newX && getYCoordinate() - 1 == newY)
					|| (getXCoordinate() - 1 == newX && getYCoordinate() + 1 == newY)) {
				setXCoordinate(newX);
				setYCoordinate(newY);
			}
		}
		else {
			log.info(getCurrentPositionAsString());
			log.info("Cannot move from current position "+getCurrentPositionAsString()+" to  "+newX+"  "+ newY);
		}

	}

	@Override
	public String toString() {
		return getCurrentPositionAsString();
	}

	protected String getCurrentPositionAsString() {
		String eol = System.lineSeparator();
		return String.format("Current X: {1}{0}Current Y: {2}{0}Piece Color: {3}", eol, xCoordinate, yCoordinate,
				pieceColor);
	}
}
