package com.ncr.chess.future;

import com.ncr.chess.ChessBoard;
import com.ncr.chess.MovementType;
import com.ncr.chess.PieceColor;

/**
 * pawns cannot move backwards. Normally a pawn moves by advancing a single square, but the first time a pawn moves, it has the option of advancing two squares
 * 
 * @author ajaykumar.singaraju
 *
 */
public class Pawn extends Piece {
	
	private ChessBoard chessBoard;
	private int xCoordinate;
	private int yCoordinate;
	private PieceColor pieceColor;

	public ChessBoard getChessBoard() {
		return chessBoard;
	}

	public void setChessBoard(ChessBoard chessBoard) {
		this.chessBoard = chessBoard;
	}

	public int getxCoordinate() {
		return xCoordinate;
	}

	public void setxCoordinate(int xCoordinate) {
		this.xCoordinate = xCoordinate;
	}

	public int getyCoordinate() {
		return yCoordinate;
	}

	public void setyCoordinate(int yCoordinate) {
		this.yCoordinate = yCoordinate;
	}

	public PieceColor getPieceColor() {
		return pieceColor;
	}

	public void setPieceColor(PieceColor pieceColor) {
		this.pieceColor = pieceColor;
	}

	@Override
	public void move(MovementType movementType, int newX, int newY) {
		throw new UnsupportedOperationException("Implement 	Pawn Move");

	}

}
