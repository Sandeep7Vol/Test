package com.ncr.chess.future;

import com.ncr.chess.MovementType;

/**
 * This is a piece class it is an abstract class from which all the actual pieces are inherited
 * we can define all the common functions
 * the move() function is an abstract class that has to be overriden by all the inherited classes
 * 
 * @author ajaykumar.singaraju
 *
 */
public abstract class Piece {
	
	
	
	public abstract void move(MovementType movementType, int newX, int newY);

}
